**REQUIREMENTS**

Complete:
- All UI is easy to see
- There is BGM and sound affects for leveling up present
- The player gains experience and can level up
- Leveling up increases stats
	(You can notice your health and damage go up)
		(Enemies start needing 7 hits, then 5 hits, then 4)
- There are NPCs around the different map areas
- There are quests
		(Inn Keeper still gives a quest to visit the Boss Area and one of the adventurers will ask you to help kill the boss)
- There are multiple areas to visit
- You can exit the game through the main menu

Incomplete:	
-There is no volume sliders in game
- There aren't any items working
- The game doesn't end after any quests
