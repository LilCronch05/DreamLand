I don't know what happened. but you need to type in the player name AFTER you play for it to
save the name with the highscore.

Press "esc" to leave the game.

upon replay the highscore willbe updated and the previous name will be in the input field.