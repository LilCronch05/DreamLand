The XML saving stopped woking due to an odd error.

And when the game loads the stats and other profile information doesn't
transfer.